# SAFIYANU FLASH TOOL V2

Windows prototype with real Windows Plug-and-Play USB/Android device detection.

## Requirements
- Windows 10/11
- .NET 8 SDK
- For some phones: the correct OEM/ADB USB driver

## Run
Open a terminal in this folder and run:
`dotnet restore`
`dotnet run`

Or open `SafiyanuFlashTool.csproj` in Visual Studio.

## What V2 does
- Scans real Windows PnP devices through WMI
- Filters USB/Android/ADB/Fastboot/MediaTek/Qualcomm-related entries
- Shows name, status, class and Device ID
- Lets you select a device and view its hardware ID
- Optional automatic scanning every 3 seconds

## Safety
This version detects devices only. It does NOT write firmware, unlock bootloaders, bypass security, or modify phones.
