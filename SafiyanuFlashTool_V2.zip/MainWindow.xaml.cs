using System;
using System.Collections.Generic;
using System.Management;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace SafiyanuFlashTool;

public class UsbDevice
{
    public string Name { get; set; } = "";
    public string Status { get; set; } = "";
    public string PnpClass { get; set; } = "";
    public string DeviceId { get; set; } = "";
}

public partial class MainWindow : Window
{
    private readonly DispatcherTimer scanTimer = new();
    private bool scanning;

    public MainWindow()
    {
        InitializeComponent();
        scanTimer.Interval = TimeSpan.FromSeconds(3);
        scanTimer.Tick += async (_, _) => await ScanAsync();
        Log("SAFIYANU FLASH TOOL V2 started.");
        Log("Real Windows PnP/USB detection enabled.");
        _ = ScanAsync();
    }

    void Log(string s)
    {
        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {s}{Environment.NewLine}");
        LogBox.ScrollToEnd();
    }

    private async Task ScanAsync()
    {
        if (scanning) return;
        scanning = true;
        try
        {
            var devices = await Task.Run(() =>
            {
                var list = new List<UsbDevice>();
                using var searcher = new ManagementObjectSearcher(
                    "SELECT Name, Status, PNPClass, DeviceID FROM Win32_PnPEntity");
                foreach (ManagementObject d in searcher.Get())
                {
                    string name = d["Name"]?.ToString() ?? "";
                    string id = d["DeviceID"]?.ToString() ?? "";
                    string cls = d["PNPClass"]?.ToString() ?? "";
                    string status = d["Status"]?.ToString() ?? "";
                    bool relevant =
                        id.StartsWith("USB\\", StringComparison.OrdinalIgnoreCase) ||
                        id.StartsWith("USBSTOR\\", StringComparison.OrdinalIgnoreCase) ||
                        cls.Equals("USB", StringComparison.OrdinalIgnoreCase) ||
                        name.Contains("Android", StringComparison.OrdinalIgnoreCase) ||
                        name.Contains("ADB", StringComparison.OrdinalIgnoreCase) ||
                        name.Contains("MediaTek", StringComparison.OrdinalIgnoreCase) ||
                        name.Contains("PreLoader", StringComparison.OrdinalIgnoreCase) ||
                        name.Contains("Qualcomm", StringComparison.OrdinalIgnoreCase) ||
                        name.Contains("Fastboot", StringComparison.OrdinalIgnoreCase);
                    if (relevant)
                        list.Add(new UsbDevice { Name=name, Status=status, PnpClass=cls, DeviceId=id });
                }
                return list;
            });

            DeviceGrid.ItemsSource = devices;
            ConnectionStatus.Text = devices.Count > 0 ? $"● {devices.Count} DEVICE(S) FOUND" : "● NO DEVICE";
            ConnectionStatus.Foreground = devices.Count > 0
                ? System.Windows.Media.Brushes.LightGreen
                : System.Windows.Media.Brushes.LightCoral;
            Log($"USB scan complete: {devices.Count} relevant device(s) found.");
        }
        catch (Exception ex)
        {
            Log("USB scan error: " + ex.Message);
        }
        finally { scanning = false; }
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await ScanAsync();

    private void DeviceGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (DeviceGrid.SelectedItem is UsbDevice d)
        {
            SelectedName.Text = d.Name;
            SelectedStatus.Text = "Status: " + d.Status;
            SelectedClass.Text = "Class: " + d.PnpClass;
            HardwareIdBox.Text = d.DeviceId;
            Log("Selected: " + d.Name);
        }
    }

    private void Connect_Click(object sender, RoutedEventArgs e)
    {
        if (DeviceGrid.SelectedItem is UsbDevice d)
        {
            Log("Device selected for service: " + d.Name);
            MessageBox.Show("Device detected successfully. Real chipset communication will be added in a later module.",
                "SAFIYANU FLASH TOOL V2", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        else MessageBox.Show("Select a device first.");
    }

    private void Info_Click(object sender, RoutedEventArgs e)
    {
        if (DeviceGrid.SelectedItem is UsbDevice d)
            MessageBox.Show($"Name: {d.Name}\nStatus: {d.Status}\nClass: {d.PnpClass}\nDevice ID: {d.DeviceId}",
                "Device Information");
        else MessageBox.Show("Select a device first.");
    }

    private void AutoScan_Click(object sender, RoutedEventArgs e)
    {
        if (AutoScanBox.IsChecked == true)
        {
            scanTimer.Start();
            Log("Auto-scan enabled.");
        }
        else
        {
            scanTimer.Stop();
            Log("Auto-scan disabled.");
        }
    }
}
